import javax.swing.*;
import java.awt.*;

public class Stats extends JComponent
{
    private int keysCollected;
    private int health;
    private Image heart;
    private Image key;

    // sets up the stats
    public Stats()
    {
        keysCollected = 0;
        health = 5;
        ImageIcon h = new ImageIcon("heart.png");
        heart = h.getImage();
        ImageIcon k = new ImageIcon("key.png");
        key = k.getImage();
    }

    // method to draw the stats
    public void draw(Graphics2D g2)
    {
        // health located in the upper left hand corner
        // number of hearts drawn depends on how much health there is left
        int x = 20;
        for(int i = 0; i < health; i++)
        {
            g2.drawImage(heart, x, 10, null);
            x = x + 38;
        }
        // draws the key image
        g2.drawImage(key, 20, 45, null);
        // draws the number of keys that the player has collected next to the key image
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Serif", Font.PLAIN, 30));
        g2.drawString(Integer.toString(keysCollected), 60, 85);
    }

    // returns the number of keys collected
    public int keysCollected()
    {
        return keysCollected;
    }

    // returns the amount of health left
    public int getHealth()
    {
        return health;
    }

    // increases the count for keys collected
    public void addKey()
    {
        keysCollected++;
    }

    // decreases the health
    public void subtractHealth()
    {
        health--;
    }

    // resets the health and number of keys collected
    public void reset()
    {
        health = 5;
        keysCollected = 0;
    }
}