import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Background extends JComponent
{
    private int initialX;
    private int initialY;
    private int x;
    private int y;
    private Image bgImg;
    public static final int WIDTH = 3900;

    // constructor for background objects
    public Background()
    {
        x = 0;
        y = 0;
        initialX = x;
        initialY = y;
        ImageIcon i = new ImageIcon("background.jpg");
        bgImg = i.getImage();
    }

    // returns the x coordinate
    public int getXCoord()
    {
        return x;
    }

    // returns the y coordinate
    public int getYCoord()
    {
        return y;
    }

    // returns the image
    public Image getImg()
    {
        return bgImg;
    }

    // moves the background by dx and dy
    public void move(int dx, int dy)
    {
        x = x + dx;
        y = y + dy;
    }

    // resets the background
    public void reset()
    {
        x = initialX;
        y = initialY;
    }
}
