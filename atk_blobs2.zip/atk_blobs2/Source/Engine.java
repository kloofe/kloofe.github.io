import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import javax.sound.sampled.*;

public class Engine
{
    public static final int WIDTH = 780;
    public static final int HEIGHT = 630;
    
    public Engine()
    {
        // constructs frame and sets all necessary attributes
        final JFrame frame = new JFrame();
        frame.setSize(WIDTH, HEIGHT);
        frame.setLayout(new FlowLayout());
        frame.setTitle("Attack of the Blobs II");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // constructs the JPanel that will contain all of the different screens
        final JPanel wrapper = new JPanel(new CardLayout());

        // constructs the menu screen and sets its size
        final JLayeredPane menu = new JLayeredPane();
        menu.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        // creates the background for the menu, positioning it and setting its size
        JLabel bg = new JLabel(new ImageIcon("splash.png"));
        bg.setBounds(0, 0, WIDTH, HEIGHT);
        // the start button
        JButton start = new JButton();
        start.setIcon(new ImageIcon("play.png"));
        start.setBorderPainted(false);
        start.setPreferredSize(new Dimension(126, 103));
        start.setRolloverIcon(new ImageIcon("play_h.png"));
        start.setBounds(475, 250, 126, 103);
        // the rules button

        JButton rules = new JButton();
        rules.setIcon(new ImageIcon("rules.png"));
        rules.setBorderPainted(false);
        rules.setPreferredSize(new Dimension(178, 103));
        rules.setRolloverIcon(new ImageIcon("rules_h.png"));
        rules.setBounds(525, 400, 178, 103);
        // adding the bg and two buttons then adding the menu to the wrapper panel
        menu.add(bg, new Integer(0));
        menu.add(start, new Integer(1));
        menu.add(rules, new Integer(2));
        wrapper.add(menu, "Menu");

        // constructs the instructions screen and sets its size
        final JLayeredPane instructions = new JLayeredPane();
        instructions.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        // constructs the background for the screen, setting its size and position
        JLabel bgRP = new JLabel(new ImageIcon("rules_page.png"));
        bgRP.setBounds(0, 0, WIDTH, HEIGHT);
        // back to menu button
        JButton back2Menu = new JButton("Menu");
        back2Menu.setBounds(650, 500, 70, 40);
        // adding the background and the back button then adding the instructions to the wrapper panel
        instructions.add(bgRP, new Integer(0));
        instructions.add(back2Menu, new Integer(1));
        wrapper.add(instructions, "Rules");

        // the game over screen
        final JLayeredPane gameOver = new JLayeredPane();
        gameOver.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        // background for the screen
        JLabel bgGO = new JLabel(new ImageIcon("game_over.png"));
        bgGO.setBounds(0, 0, WIDTH, HEIGHT);
        // play again button
        JButton playAgain = new JButton("Play Again");
        playAgain.setBounds(355, 400, 100, 40);
        // adds everything
        gameOver.add(bgGO, new Integer(0));
        gameOver.add(playAgain, new Integer(1));
        wrapper.add(gameOver, "Game Over");

        // the win screen
        final JLayeredPane win = new JLayeredPane();
        win.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        // the background for the screen
        JLabel bgW = new JLabel(new ImageIcon("end_screen.png"));
        bgW.setBounds(0, 0, WIDTH, HEIGHT);
        // back to menu button
        JButton back = new JButton("Menu");
        back.setBounds(370, 420, 70, 40);
        // adding the background and button and then adding the win screen to the wrapper panel
        win.add(bgW, new Integer(0));
        win.add(back, new Integer(1));
        wrapper.add(win, "Win");

        // constructs the world
        final World world = new World();
        world.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        // adds the world to the wrapper panel
        wrapper.add(world, "World");

        // gets the CardLayout from the wrapper panel
        final CardLayout cl = (CardLayout) wrapper.getLayout();

        // the listener for the start button
        class startListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                // shows the world, starts it
                cl.show(wrapper, "World");
                world.start();
                // tries to set it focusable but it doesn't work...
                world.setFocusable(true);
                world.requestFocusInWindow();
            }
        }

        // the listener for the back2Menu button
        class back2MenuListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                // shows the menu screen (which is first in the list)
                cl.first(wrapper);
            }
        }

        // the listener for the go to rules button
        class rulesListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                // shows the rules screen
                cl.show(wrapper, "Rules");
            }
        }

        // listener for the play again button
        class playAgainListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                // shows the world
                cl.show(wrapper, "World");
                // restarts the world and then starts it
                world.restart();
                world.start();
                world.requestFocusInWindow();
            }
        }

        // the listener for the world
        class worldListener implements GameListener
        {
            public void gameEventReceived(GameEvent e)
            {
                // if the event was a game over event
                if((e.getName()).equalsIgnoreCase("Game Over"))
                {
                    // stops the game
                    world.stop();
                    // shows the game over screen
                    cl.show(wrapper, "Game Over");
                    // plays the fail noise
                    fail();
                }
                // if the event was a win event
                else if((e.getName()).equalsIgnoreCase("win"))
                {
                    // stops the world
                    world.stop();
                    // shows the win screen
                    cl.show(wrapper, "Win");
                    // plays the applause noise
                    applause();
                    // resets the world incase the player wants to play again from the menu
                    world.restart();
                }
            }
        }

        // adds the listeners
        start.addActionListener(new startListener());
        rules.addActionListener(new rulesListener());
        back2Menu.addActionListener(new back2MenuListener());
        back.addActionListener(new back2MenuListener());
        playAgain.addActionListener(new playAgainListener());
        world.addGameListener(new worldListener());

        // adds the wrapper panel to the frame
        frame.add(wrapper);
        // frame is not resizable
        frame.setResizable(false);
        // frame is set to visible
        frame.setVisible(true);

        // plays the background music
        music();
    }

    // method to play the music
    public void music()
    {
        AudioInputStream bgMusic;

        // need a try catch loop for retrieving the file
        try
        {
            bgMusic = AudioSystem.getAudioInputStream(new File("dungeon_music_loop.wav"));
            // creates a clip
            Clip clip = AudioSystem.getClip();
            // clip opens the music and loops through it continuously
            clip.open(bgMusic);
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
        catch(Exception error)
        {
            // do nothing
        }
    }

    public void applause()
    {
        AudioInputStream music;

        try
        {
            music = AudioSystem.getAudioInputStream(new File("applause-8.wav"));
            Clip clip = AudioSystem.getClip();
            clip.open(music);
            // sound only plays once
            clip.start();
        }
        catch(Exception error)
        {
            // do nothing
        }
    }

    public void fail()
    {
        AudioInputStream bgMusic;

        try
        {
            bgMusic = AudioSystem.getAudioInputStream(new File("fail_trombone_01.wav"));
            Clip clip = AudioSystem.getClip();
            clip.open(bgMusic);
            // sound only plays once
            clip.start();
        }
        catch(Exception error)
        {
            // do nothing
        }
    }

    // main method
    public static void main(String[] args)
    {
        Engine engine = new Engine();
    }
}
