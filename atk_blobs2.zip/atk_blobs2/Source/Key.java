import java.awt.*;
import javax.swing.*;

public class Key extends JComponent
{
    private int x;
    private int y;
    private int initialX;
    private int initialY;
    private Image img;
    public static final int WIDTH = 27;
    public static final int HEIGHT = 60;

    // sets the position of the key and the image
    public Key(int xCoord, int yCoord)
    {
        x = xCoord;
        y = yCoord;
        initialX = x;
        initialY = y;
        ImageIcon i = new ImageIcon("key.png");
        img = i.getImage();
    }

    // returns the x coordinate
    public int getXCoord()
    {
        return x;
    }

    // returns the y coordinate
    public int getYCoord()
    {
        return y;
    }

    // returns the image
    public Image getImg()
    {
        return img;
    }

    // moves the key by dx and dy
    public void move(int dx, int dy)
    {
        x = x + dx;
        y = y + dy;
    }

    // resets the position and makes sure its visible
    public void reset()
    {
        x = initialX;
        y = initialY;
        setVisible(true);
    }
}