import java.awt.*;
import javax.swing.JComponent;
import java.awt.event.*;
import javax.swing.*;

public class Fire extends JComponent implements ActionListener
{
    private int x;
    private int y;
    private int initialX;
    private int initialY;
    private Image img;
    private Timer t;
    public static final int WIDTH = 100;
    public static final int HEIGHT = 175;

    public Fire(int xCoord, int yCoord, int delay)
    {
        x = xCoord;
        y = yCoord;
        initialX = x;
        initialY = y;
        // creates the timer for the intervals of when the fire is visible and not
        t = new Timer(delay, this);
        t.start();
        ImageIcon i = new ImageIcon("flames.gif");
        img = i.getImage();
    }

    // returns the x coordinate
    public int getXCoord()
    {
        return x;
    }

    // returns the y coordinate
    public int getYCoord()
    {
        return y;
    }

    // returns the image
    public Image getImg()
    {
        return img;
    }

    // moves the fire by dx or dy
    public void move(int dx, int dy)
    {
        x = x + dx;
        y = y + dy;
    }

    // the method called when the timer is fired
    public void actionPerformed(ActionEvent e)
    {
        // if the fire is visible, it is set to invisible
        if(isVisible())
        {
            setVisible(false);
        }
        // if the fire isn't visible, it is set to visible
        else
        {
            setVisible(true);
        }
    }

    // resets the position of the fire
    public void reset()
    {
        x = initialX;
        y = initialY;
    }
}
