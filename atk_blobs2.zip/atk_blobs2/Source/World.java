import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import javax.swing.JComponent;
import java.awt.event.*;
import javax.swing.Timer;

public class World extends JComponent implements ActionListener, KeyListener
{
    private Player player;
    private Background bg;
    private Platform[] platform;
    private Platform currentPlatform;
    private Key[] key;
    private Key currentKey;
    private Fire[] fire;
    private Stats stats;
    private Door door;
    private Timer t;
    private Camera camera;
    private List listeners;

    public World()
    {
        player = new Player();
        bg = new Background();
        platform = createPlatforms();
        currentPlatform = null;
        key = createKeys();
        currentKey = null;
        fire = createFire();
        stats = new Stats();
        door = new Door();
        camera = new Camera(player, bg, platform, key, fire, door);
        addKeyListener(this);
        t = new Timer(15, this);
        // optimizes drawing during the game loop
        setDoubleBuffered(true);
        listeners = new ArrayList();
    }

    // game loop
    public void actionPerformed(ActionEvent e)
    {   
        // checks whether a player landed on a platform while jumping
        if(landedOnPlatform() && player.isJumpingDown())
        {
            stopPlayer();
        }

        // if the player is jumping, they are not on a platform
        if(player.isJumping())
        {
            currentPlatform = null;
        }

        // Checks whether the player walked off a platform
        if(currentPlatform != null)
        {
            if(player.getXCoord() + player.getDX() + player.WIDTH/2 < currentPlatform.getXCoord() || player.getXCoord() + player.getDX() + player.WIDTH/2 > currentPlatform.getXCoord() + currentPlatform.getWidth())
            {
                player.fall();
                currentPlatform = null;
            }
        }

        // if the player runs into fire and is not currently knock backed or in their invincible frames 
        // then they enter into their invincible frames, knock backed, and lose health
        if(hurt() && !player.knockBacked() && !player.isInvincible())
        {
            player.setInvincible();
            player.knockBack();
            stats.subtractHealth();
            // If the player runs out of health, then an event is fired that signals to switch to the game over screen
            if(stats.getHealth() == 0)
            {
                fireEvent(this, "game over");
            }
        }

        // if a player has collected a key, then that key disappears and the player's key count increases
        if(collectedKey())
        {
            currentKey.setVisible(false);
            stats.addKey();
        }

        // if a player is at the door, not moving, and they have collected all 5 keys, then an event is fired that signals
        // to switch to the win screen
        if(atDoor() && player.getDY() == 0 && player.getDX() == 0 && stats.keysCollected() == 5)
        {
            fireEvent(this, "win");
        }

        // if the player is within certain borders, then only the player moves
        if(withinLeftBorder() && withinRightBorder())
        {
            player.move(player.getDX(), player.getDY());
        }
        // if the player is not within the left border, then the camera scroll lefts
        else if(!withinLeftBorder())
        {
            camera.scrollLeft();
        }
        // if the player is not within the right border, then the camera scroll rights
        else if(!withinRightBorder())
        {
            camera.scrollRight();
        }

        // if the player is not moving, then the camera recenters if need be
        if(player.getDX() == 0 && player.getDY() == 0)
        {
            camera.focus();
        }

        repaint();
    }

    // paints the world
    public void paintComponent(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;

        // draws the background
        g2.drawImage(bg.getImg(),  bg.getXCoord(), bg.getYCoord(), null);

        // draws each of the keys if they are visible
        for(int i = 0; i < key.length; i++)
        {
            if(key[i].isVisible())
            {
                g2.drawImage(key[i].getImg(), key[i].getXCoord(), key[i].getYCoord(), null);
            }
        }

        // draws the platforms if they are within the camera's view
        for(int i = 0; i < platform.length; i++)
        {
            if(camera.withinScreen(platform[i]))
            {
                platform[i].draw(g2);
            }
        }

        // draws the fire balls if they are within the camera's view and are visible
        for(int i = 0; i < fire.length; i++)
        {
            if(camera.withinScreen(fire[i]) && fire[i].isVisible())
            {
                g2.drawImage(fire[i].getImg(), fire[i].getXCoord(), fire[i].getYCoord(), null);
            }
        }

        // draws the door
        g2.drawImage(door.getImg(), door.getXCoord(), door.getYCoord(), null);

        // if the player is in its invincible frames, then the opacity is set to 50%
        if(player.isInvincible())
        {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) .5));
        }
        // draws the player
        g2.drawImage(player.getImg(),  player.getXCoord(),  player.getYCoord(), null);
        // sets the opacity back to 100%
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) 1));

        // draws the stats
        stats.draw(g2);
    }

    // checks if the player landed on a platform
    public boolean landedOnPlatform()
    {
        // loops through each platform
        for(int i = 0; i < platform.length; i++)
        {
            // if the platform is within the screen
            if(camera.withinScreen(platform[i]))
            {
                // checks for an intersection for the top of the platform
                // player current's position > platform < future position
                boolean currentPosition = player.getYCoord() + player.HEIGHT <= platform[i].getYCoord();
                boolean futurePosition = player.getYCoord() - player.getDY() + player.HEIGHT >= platform[i].getYCoord();
                boolean withinWidth = (player.getXCoord() + player.WIDTH/2 + 5 <= platform[i].getWidth() + platform[i].getXCoord() && player.getXCoord() + player.WIDTH/2 + 5 >= platform[i].getXCoord());
                boolean landedOnPlatform = currentPosition && futurePosition && withinWidth;
                // then checks whether the player is jumping down
                if(player.isJumpingDown())
                {
                    // then if the player has landed on a platform, currentPlatform is set the platform being checked
                    if(landedOnPlatform)
                    {
                        currentPlatform = platform[i];
                        // exits out of the loop
                        i = platform.length;
                    }
                    // if the player has not landed on a platform, then the currentPlatform is set to null
                    else
                    {
                        currentPlatform = null;
                    }
                }
            }
        }
        return currentPlatform != null;
    }

    // checks if the player has run into a key to collect it
    public boolean collectedKey()
    {
        // loops through all of the keys
        for(int i = 0; i < key.length; i++)
        {
            // if the key is within the screen
            if(camera.withinScreen(key[i]))
            {
                // creates boundaries for both the player and the key
                Rectangle keyBoundaries = new Rectangle(key[i].getXCoord(), key[i].getYCoord(), Key.WIDTH, Key.HEIGHT);
                Rectangle playerBoundaries = new Rectangle(player.getXCoord(), player.getYCoord(), player.WIDTH, player.HEIGHT);

                // if the boundaries intersect and the key is visible
                if(keyBoundaries.intersects(playerBoundaries) && key[i].isVisible())
                {
                    // current key is set the key in question
                    currentKey = key[i];
                    // exits out of the loop
                    i = key.length;
                }
                // if the boundaries don't intersect then the currentKey is null
                else
                {
                    currentKey = null;
                }
            }
        }
        return currentKey != null;
    }

    // checks whether the player has run into a fire ball
    public boolean hurt()
    {
        // assumes that the player hasn't
        boolean ranIntoFire = false;
        // loops through each of the fires
        for(int i = 0; i < fire.length; i++)
        {
            // if the fire is within the screen and is visible
            if(camera.withinScreen(fire[i]) && fire[i].isVisible())
            {
                // creates boundaries for both the fire and the player
                Rectangle fireBoundaries = new Rectangle(fire[i].getXCoord(), fire[i].getYCoord(), Fire.WIDTH, Fire.HEIGHT);
                Rectangle playerBoundaries = new Rectangle(player.getXCoord(), player.getYCoord(), player.WIDTH, player.HEIGHT);
                // if the boundaries intersect
                if(fireBoundaries.intersects(playerBoundaries))
                {
                    // the player did indeed run into a fire
                    ranIntoFire = true;
                    // exits out of the loop
                    i = fire.length;
                }
            }
        }
        return ranIntoFire;
    }

    // checks whether the player is at the door
    public boolean atDoor()
    {
        // creates boundaries for both the player and the door
        Rectangle doorBoundaries = new Rectangle(door.getXCoord(), door.getYCoord(), Door.WIDTH, Door.HEIGHT);
        Rectangle playerBoundaries = new Rectangle(player.getXCoord(), player.getYCoord(), player.WIDTH, player.HEIGHT);
        // returns whether the player is completely within the boundaries of the door
        return doorBoundaries.contains(playerBoundaries);
    }

    // stops the player from continuing to jump
    public void stopPlayer()
    {
        // sets the jump to false
        player.setJump(false);
        // stops the player if they are knock backed
        if(player.knockBacked())
        {
            player.setKnockBackedFalse();
        }

        // makes sure the player is right on top of the platform
        if(player.getYCoord() + player.getDY() + player.HEIGHT >= currentPlatform.getYCoord())
        {
            player.moveTo(player.getXCoord(), currentPlatform.getYCoord() - player.HEIGHT);
        }
    }

    // checks whether player is within the left border
    public boolean withinLeftBorder()
    {
        return player.getXCoord() + player.getDX() > Camera.WIDTH/2 - 50;
    }

    // checks whether the player is within the right border
    public boolean withinRightBorder()
    {
        return player.getXCoord() + player.getDX() < Camera.WIDTH/2 + 50;
    }

    // creates all the platforms in the game
    public Platform[] createPlatforms()
    {
        Platform[] p = { new Platform(0, 550, Background.WIDTH, 75),
                /* cheat platforms
                new Platform(610, 450, 100, 50),
                new Platform(610, 350, 100, 50),
                new Platform(610, 250, 100, 50),
                new Platform(1150, 450, 75, 50),
                new Platform(1150, 250, 75, 50),
                new Platform(2380, 450, 75, 50),
                new Platform(2380, 350, 75, 50),
                new Platform(2380, 250, 75, 50),
                new Platform(2380, 150, 75, 50),
                new Platform(3120, 230, 100, 50),
                new Platform(3120, 450, 100, 50),
                new Platform(3120, 350, 100, 50),
                new Platform(3600, 450, 200, 50),
                new Platform(3600, 330, 200, 50),
                */
                new Platform(100, 450, 200, 50),
                new Platform(350, 370, 200, 50),
                new Platform(100, 290, 200, 50),
                new Platform(370, 180, 100, 50),
                new Platform(610, 180, 100, 50),
                new Platform(850, 180, 100, 50),
                new Platform(1150, 370, 75, 50),
                new Platform(1300, 270, 75, 50),
                new Platform(1150, 190, 75, 50),
                new Platform(1300, 90, 75, 50),
                new Platform(1570, 290, 75, 50),
                new Platform(1570, 170, 150, 50),
                new Platform(1850, 230, 150, 50),
                new Platform(2100, 300, 75, 50),
                new Platform(2280, 350, 75, 50),
                new Platform(2460, 300, 75, 50),
                new Platform(2100, 160, 75, 50),
                new Platform(2280, 110, 75, 50),
                new Platform(2460, 160, 75, 50),
                new Platform(2640, 230, 100, 50),
                new Platform(2880, 230, 100, 50),
                new Platform(3120, 230, 100, 50),
                new Platform(3360, 230, 100, 50),
                new Platform(3600, 230, 200, 50)

            };
        return p;
    }

    // creates all the keys
    public Key[] createKeys()
    {
        Key[] k = { 
                new Key(650, 180 - Key.HEIGHT),
                new Key(1170, 190 - Key.HEIGHT),
                new Key(2480, 300 - Key.HEIGHT),
                new Key(2300, 110 - Key.HEIGHT),
                new Key(3150, 230 - Key.HEIGHT)
            };
        return k;
    }

    // creates all the fire balls
    public Fire[] createFire()
    {
        Fire[] f = { 
                new Fire(375, 180 - Fire.HEIGHT, 2000),
                new Fire(850, 180 - Fire.HEIGHT, 3000),
                new Fire(1300, 270 - Fire.HEIGHT, 2100),
                new Fire(2280, 350 - Fire.HEIGHT, 1550),
                new Fire(2100, 160 - Fire.HEIGHT, 1700),
                new Fire(2460, 160 - Fire.HEIGHT, 2000),
                new Fire(2640, 230 - Fire.HEIGHT, 1850),
                new Fire(3360, 230 - Fire.HEIGHT, 1500)
            };
        return f;
    }

    // listens for key presses
    // imageTo(image, state)
    // state: 1, 2, 3 - static, walking, jumping right respectively
    // state: -1, -2, -3 - static, walking, jumping left repsectively
    public void keyPressed(KeyEvent e)
    {
        int key = e.getKeyCode();
        // the player turns and moves left if the left key is pressed as long as they are not in the air
        if(key == KeyEvent.VK_LEFT && !player.isJumping() && !player.knockBacked())
        {
            player.setDX(-5);
            player.imageTo(Player.LEFT, -2);
        }

        // the player turns and moves right if the right key is pressed as long as they are not in the air
        if(key == KeyEvent.VK_RIGHT && !player.isJumping() && !player.knockBacked())
        {
            player.setDX(5);
            player.imageTo(Player.RIGHT, 2);
        }

        // the player jumps if space is pressed as long as the player is not in the air already
        if(key == KeyEvent.VK_SPACE  && !player.isJumping() && !player.knockBacked())
        {
            player.setDY(15);
            player.setJump(true);

            // whether player looks like it is jumping to the left or right depends on whether they are already facing left or right
            if(player.getState() == -1 || player.getState() == -2)
            {
                player.imageTo(Player.LEFT_JUMP, -3);
            }
            else if(player.getState() == 2 || player.getState() == 1)
            {
                player.imageTo(Player.RIGHT_JUMP, 3);
            }
        }
    }

    // listens for a key being released
    // when the left/right key is released, the player stops moving
    public void keyReleased(KeyEvent e)
    {
        int key = e.getKeyCode();
        if(key == KeyEvent.VK_LEFT)
        {
            player.setDX(0);
            player.imageTo(Player.LEFT_STATIC, -1);
        }

        if(key == KeyEvent.VK_RIGHT)
        {
            player.setDX(0);
            player.imageTo(Player.RIGHT_STATIC, 1);
        }
    }

    public void keyTyped(KeyEvent e)
    {
        // do nothing
    }

    // starts the game loop
    public void start()
    {
        t.start();
    }

    // stops the game loop
    public void stop()
    {
        t.stop();
    }

    // restarts the world
    public void restart()
    {
        // resets the camera
        camera.reset();
        // resets the stats
        stats.reset();
    }

    // adds the custom event listener
    public synchronized void addGameListener(GameListener listener)  
    {
        listeners.add(listener);
    }

    // removes the custom event listener
    public synchronized void removeEventListener(ActionListener listener)   
    {
        listeners.remove(listener);
    }

    // fires a game event
    public synchronized void fireEvent(Object source, String n)
    {
        GameEvent event = new GameEvent(source, n);
        // goes through the game listeners
        Iterator gameListeners = listeners.iterator();
        while(gameListeners.hasNext())
        {
            // calls gameEventReceived on the listener
            ((GameListener) gameListeners.next()).gameEventReceived(event);
        }
    }
}