import java.util.EventObject;

// custom event
public class GameEvent extends EventObject
{
    // the string that the event is associated with
    private String name;
    
    public GameEvent(Object source, String n)
    {
        // call to the super constructor
        super(source);
        name = n;
    }

    // returns the name associated with the event
    public String getName()
    {
        return name;
    }
}
