// interface that listeners will implement
public interface GameListener
{
    void gameEventReceived(GameEvent e);
}
