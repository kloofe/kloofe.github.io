import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Player extends JComponent implements ActionListener
{
    private int initialX;
    private int initialY;
    private int x;
    private int y;
    private int dx;
    private int dy;
    private double t;
    private boolean jumping = false;
    private boolean knockBacked = false;
    private Image img;
    private Timer invincibleFrames;
    private int state;
    public static final ImageIcon LEFT_STATIC = new ImageIcon("blob_left_static.gif");
    public static final ImageIcon RIGHT_STATIC = new ImageIcon("blob_right_static.gif");
    public static final ImageIcon LEFT = new ImageIcon("blob_left.gif");        
    public static final ImageIcon RIGHT = new ImageIcon("blob_right.gif");       
    public static final ImageIcon LEFT_JUMP = new ImageIcon("blob_jumping_left.gif");
    public static final ImageIcon RIGHT_JUMP = new ImageIcon("blob_jumping_right.gif");
    public static final int WIDTH = 105;
    public static final int HEIGHT = 65;

    public Player()
    {
        dx = 0;
        dy = 0;
        x = 350;
        y = 475;
        initialX = x;
        initialY = y;
        // invincible frames timer
        invincibleFrames = new Timer(1000, this);
        img = RIGHT_STATIC.getImage();
        // default state is facing right and not moving
        state = 1;
    }

    // returns the x coordinate
    public int getXCoord()
    {
        return x;
    }
    
    // returns the y coordinate
    public int getYCoord()
    {
        return y;
    }

        // returns the image
    public Image getImg()
    {
        return img;
    }

    // returns the dx
    public int getDX()
    {
        return dx;
    }

    // returns the dy
    public int getDY()
    {
        return dy;
    }

    // returns the state
    public int getState()
    {
        return state;
    }

    // sets the dx
    public void setDX(int dx2)
    {
        dx = dx2;
    }

    // sets the dy
    public void setDY(int dy2)
    {
        dy = dy2;
    }

    // starts a knock back
    public void knockBack()
    {
        dy = 10;
        // is knock backed the opposite way the player is facing
        if(state == 1 || state == 2 || state == 3)
        {
            dx = -5;
        }
        else 
        {
            dx = 5;
        }
        knockBacked = true;
    }

    // returns whether or not the player is currently knock backed
    public boolean knockBacked()
    {
        return knockBacked;
    }
    
    // stops the knock back effect
    public void setKnockBackedFalse()
    {
        knockBacked = false;
        dx = 0;
    }

    // returns whether the player is jumping
    public boolean isJumping()
    {
        return jumping;
    }

    // returns whether or not the player is jumping down
    public boolean isJumpingDown()
    {
        return dy < 0;
    }

    // starts a fall
    public void fall()
    {
        dy = 0;
        jumping = true;
    }

    // sets whether the player is jumping or not
    public void setJump(boolean jumpBoolean)
    {
        jumping = jumpBoolean;
        // if the player is not jumping
        if(!jumping)
        {
            // dy is 0
            dy = 0;
            // the image depends on whether the player had been jumping left or right and whether is moving left or right when it the jump is stopped
            if(state == 3)
            {
                if(dx == 5)
                {
                    imageTo(RIGHT, 2);
                }
                else
                {
                    imageTo(RIGHT_STATIC, 1);
                }
            }
            else if(state == -3)
            {
                if(dx == -5)
                {
                    imageTo(LEFT, -2);
                }
                else
                {
                    imageTo(LEFT_STATIC, -1);
                }
            }
        }
    }

    // moves the player to a certain location
    public void moveTo(int xCoord, int yCoord)
    {
        x = xCoord;
        y = yCoord;
    }

    // updates the x and y
    public void move(int dx2, int dy2)
    {
        x = x + dx2; // dx = v_x * dt

        // if the player is jumping
        if(jumping)
        {
            // new y based on the dy
            y = y - dy2;
            // dy decreased by 1
            dy = dy2 - 1;
            // max speed when going down is -15
            if(dy < -15)
            {
                dy = -15;
            }
        }
        else if(knockBacked)
        {
            y = y - dy2;
            dy = dy2 - 1;
            // max speed when going down in a knock back is -10
            if(dy < -10)
            {
                dy = -10;
            }
        }
    }

    // changes the state the player is in (ie walking, not moving, jumping)
    public void imageTo(ImageIcon i, int s)
    {
        img = i.getImage();
        state = s;
    }

    // 1.5 seconds is up, the invincible frames stop
    public void actionPerformed(ActionEvent e)
    {
        invincibleFrames.stop();
    }    

    public void setInvincible()
    {
        // the length of the invincible frames
        invincibleFrames.setInitialDelay(1500); 
        // starts the invincible frames
        invincibleFrames.start();
    }

    // returns whether the player is currently invincible
    public boolean isInvincible()
    {
        return invincibleFrames.isRunning();
    }

    // resets the player to default
    public void reset()
    {
        x = initialX;
        y = initialY;
        dx = 0;
        dy = 0;
        jumping = false;
        knockBacked = false;
        imageTo(RIGHT_STATIC, 1);
    }
}