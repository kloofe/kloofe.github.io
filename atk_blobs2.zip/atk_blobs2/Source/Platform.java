import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Platform extends JComponent
{
    private int initialX;
    private int initialY;
    private Image texture;
    private static final ImageIcon PLATFORM_TEXTURE = new ImageIcon("platform.png");
    private int width;
    private int y;
    private int x;
    private Rectangle boundaries;

    // position, width and height
    public Platform(int xCoord, int yCoord, int w, int h)
    {
        x = xCoord;
        y = yCoord;
        initialX = x;
        initialY = y;
        // creates a rectangle of the boundaries of the platform
        boundaries = new Rectangle(x, y, w, h);
        texture = PLATFORM_TEXTURE.getImage();
    }

    public void draw(Graphics2D g2)
    {
        // sets the clip as the boundaries of the platform
        g2.setClip(boundaries);
        // draws the image with the set clipping
        g2.drawImage(texture, x, y, null);
        // no more clipping
        g2.setClip(null);
    }

    // returns the boundaries
    public Rectangle getRect()
    {
        return boundaries;
    }

    // gets the width
    public int getWidth()
    {
        return (int) boundaries.getWidth();
    }

    // returns the y coordinate
    public int getYCoord()
    {
        return y;
    }

    // returns the x coordinate
    public int getXCoord()
    {
        return x;
    }

    // moves the platform by dx and dy
    public void move(int dx, int dy)
    {
        x = x + dx;
        y = y + dy;
        boundaries.translate(dx, dy);
    }

    // resets the position of the platform
    public void reset()
    {
        x = initialX;
        y = initialY;
        // shifts the boundaries, too, so that the cliping is correct
        boundaries = new Rectangle(x, y, (int) boundaries.getWidth(), (int) boundaries.getHeight());
    }
}