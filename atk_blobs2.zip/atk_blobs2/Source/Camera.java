import java.awt.*;

public class Camera
{
    private Player player;
    private Background bg;
    private Platform[] platform;
    private Key[] key;
    private Fire[] fire;
    private Door door;
    private Rectangle screen;
    public static final int WIDTH = Engine.WIDTH;
    public static final int HEIGHT = Engine.HEIGHT;

    // initializes all of the instance fields
    public Camera(Player c, Background b, Platform[] p, Key[] k, Fire[] f, Door d)
    {
        player = c;
        bg = b;
        platform = p;
        key = k;
        fire = f;
        door = d;
        screen = new Rectangle(0, 0, WIDTH, HEIGHT);
    }

    // focus the camera
    public void focus()
    {
        // if the camera can go further left or right
        if(!atLeftEdge() && !atRightEdge())
        {
            // if past the left border
            if(!withinLeftBorder())
            {
                // moves everything to within the border
                bg.move(-2, 0);
                player.move(-2, 0);
                moveAllObjects(-2, 0);
            }
            // if past the right border
            else if(!withinRightBorder())
            {
                // moves everything to within the border
                bg.move(2, 0);
                player.move(2, 0);
                moveAllObjects(2, 0);
            }
        }
    }

    // cameral scrolls left
    public void scrollLeft()
    {
        // if the camera can't go further left
        if(atLeftEdge())
        {
            // if the player is at the left edge and is moving left
            if(player.getXCoord() + player.getDX() <= 0 && player.getDX() != 5)
            {
                // the player can just jump
                player.move(0, player.getDY());
            }
            // player moves freely
            else
                player.move(player.getDX(), player.getDY());
        }
        // if the camera can go further left
        else
        {
            // the background and all of the objects move the opposite way of the player
            bg.move(-player.getDX(), 0);
            moveAllObjects(-player.getDX(), 0);
            // relative to the camera, the player does not move except for jumping
            player.move(0, player.getDY());
        }
    }

    // same thing as scrolling left only for right side
    public void scrollRight()
    {
        if(atRightEdge())
        {
            if(player.getXCoord() + player.getDX() >= WIDTH -  player.WIDTH && player.getDX() != -5)
            {
                player.move(0, player.getDY());
            }
            else
                player.move(player.getDX(), player.getDY());
        }
        else
        {
            bg.move(-player.getDX(), 0);
            moveAllObjects(-player.getDX(), 0);
            player.move(0, player.getDY());
        }
    }

    // checks whether player is within the left border
    public boolean withinLeftBorder()
    {
        return player.getXCoord() <= WIDTH/2 + 5;
    }

    // checks whether the player is within the right border
    public boolean withinRightBorder()
    {
        return player.getXCoord() >= WIDTH/2 - 5;
    }

    // Returns whether or not you can continue left
    public boolean atLeftEdge()
    {
        return bg.getXCoord() >= 0;
    }

    // Returns whether or not you can continue right
    public boolean atRightEdge()
    {
        return bg.getXCoord() <= WIDTH - Background.WIDTH;
    }

    // moves all the objects
    public void moveAllObjects(int dx, int dy)
    {
        for(int i = 0; i < platform.length; i++)
        {
            platform[i].move(dx, dy);
        }

        for(int i = 0; i < key.length; i++)
        {
            key[i].move(dx, dy);
        }

        for(int i = 0; i < fire.length; i++)
        {
            fire[i].move(dx, dy);
        }

        door.move(dx, dy);
    }

    // checks whether a platform is within the boundaries of the screen
    public boolean withinScreen(Platform p)
    {
        return screen.intersects(p.getRect());
    }

    // does the check for a key
    public boolean withinScreen(Key k)
    {
        Rectangle keyBoundaries = new Rectangle(k.getXCoord(), k.getYCoord(), k.WIDTH, k.HEIGHT);
        return screen.intersects(keyBoundaries);
    }

    // does the check for fire balls
    public boolean withinScreen(Fire f)
    {
        Rectangle fireBoundaries = new Rectangle(f.getXCoord(), f.getYCoord(), f.WIDTH, f.HEIGHT);
        return screen.intersects(fireBoundaries);
    }

    // does the check for the door
    public boolean withinScreen(Door d)
    {
        Rectangle doorBoundaries = new Rectangle(d.getXCoord(), d.getYCoord(), d.WIDTH, d.HEIGHT);
        return screen.intersects(doorBoundaries);
    }

    // resets the view of the camera
    public void reset()
    {
        // moves everything back to their original position
        bg.reset();
        player.reset();
        door.reset();

        for(int i = 0; i < platform.length; i++)
        {
            platform[i].reset();
        }

        for(int i = 0; i < key.length; i++)
        {
            key[i].reset();
        }

        for(int i = 0; i < fire.length; i++)
        {
            fire[i].reset();
        }
    }
}