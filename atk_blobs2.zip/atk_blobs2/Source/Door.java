import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Door extends JComponent
{
    private int initialX;
    private int initialY;
    private int x;
    private int y;
    private Image img;
    public static final int WIDTH = 200;
    public static final int HEIGHT = 237;

    // positions the door and sets the image
    public Door()
    {
        x = 3600;
        y = 5;
        initialX = x;
        initialY = y;
        ImageIcon i = new ImageIcon("door.png");
        img = i.getImage();
    }

    // returns the x coordinate
    public int getXCoord()
    {
        return x;
    }

    // returns the y coordinate
    public int getYCoord()
    {
        return y;
    }
    
    // returns the image
    public Image getImg()
    {
        return img;
    }

    // moves the door by dx or dy
    public void move(int dx, int dy)
    {
        x = x + dx;
        y = y + dy;
    }

    // resets the position
    public void reset()
    {
        x = initialX;
        y = initialY;
    }
}
