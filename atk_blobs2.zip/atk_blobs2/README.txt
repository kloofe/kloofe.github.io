--------------
INTRODUCTION
--------------

Version: 1.0
Author: Nina Volkmuth

Play as a captured Blob and try to escape from prison by collecting all the keys, jumping across platforms, and avoiding fires. Make it to the door successfully to regain your freedom.

--------------
USAGE NOTES
--------------

To play the game, simply run the jar file. Must have java (preferably latest version) installed.

--------------
DISCLAIMER
--------------

Nina Volkmuth claims no ownership over any of the music in this game. This game is not intended to be sold in any way shape or form. 