--------------
INTRODUCTION
--------------

Version: 1.0
Author: Nina Volkmuth

Play as Fabby from the original Flappy Bird and make your way back to your home by flying through three different games in the original Flabby Bird style. Collect powerups to aid Fabby in his quest but make sure to avoid obstacles that will hinder him. 

--------------
USAGE NOTES
--------------

To play the game, simply run the jar file. Must have java (preferably latest version) installed.

--------------
DISCLAIMER
--------------

Nina Volkmuth claims no ownership over any of the music, background images, or other games referenced in this game. This game is not intended to be sold in any way shape or form. 