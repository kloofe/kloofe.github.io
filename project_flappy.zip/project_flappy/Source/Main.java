import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main
{

    public static void main(String[] args)
    {
        final int WIDTH = 550;
        final int HEIGHT = 600;

        final JFrame frame = new JFrame();
        frame.setSize(WIDTH, HEIGHT);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // constructs the JPanel that will contain all of the different screens
        final JPanel wrapper = new JPanel(new CardLayout());

        // constructs the menu screen
        final JLayeredPane menu = new JLayeredPane();
        menu.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        JLabel menuBG = new JLabel(new ImageIcon("Images/menu_screen.png"));
        menuBG.setBounds(0, 0, WIDTH, HEIGHT);
        JButton start = new JButton();
        start.setIcon(new ImageIcon("Images/play_button.png"));
        start.setBounds(WIDTH/2 - 35, 300, 70, 40);
        start.setBorderPainted(false);
        JButton toRules = new JButton();
        toRules.setBorderPainted(false);
        toRules.setIcon(new ImageIcon("Images/rules_button.png"));
        toRules.setBounds(WIDTH/2 - 35, 400, 70, 35);
        menu.add(start, new Integer(2));
        menu.add(toRules, new Integer(1));
        menu.add(menuBG, new Integer(0));
        wrapper.add(menu, "Menu");

        // constructs level complete screen
        final JLayeredPane lvlComplete = new JLayeredPane();
        lvlComplete.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        JLabel lvlBG = new JLabel(new ImageIcon("Images/levelcomplete_screen.png"));
        lvlBG.setBounds(0, 0, WIDTH, HEIGHT);
        JButton cont = new JButton();
        cont.setIcon(new ImageIcon("Images/nextlvl.png"));
        cont.setBounds(WIDTH/2 - 75,400, 150, 40);
        cont.setBorderPainted(false);
        lvlComplete.add(cont, new Integer(1));
        lvlComplete.add(lvlBG, new Integer(0));
        wrapper.add(lvlComplete, "LvlComplete");

        // constructs the story screen
        final JLayeredPane story = new JLayeredPane();
        story.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        JLabel storyBG = new JLabel(new ImageIcon("Images/story.png"));
        storyBG.setBounds(0, 0, WIDTH, HEIGHT);
        JButton next = new JButton();
        next.setIcon(new ImageIcon("Images/next.png"));
        next.setBorderPainted(false);
        next.setBounds(400, 475, 65, 35);
        story.add(next, 2);
        story.add(storyBG, 1);
        wrapper.add(story, "Story");

        // constructs the rules screen
        final JLayeredPane rules = new JLayeredPane();
        rules.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        JLabel rulesBG = new JLabel(new ImageIcon("Images/rules.png"));
        rulesBG.setBounds(0, 0, WIDTH, HEIGHT);
        JButton toMenu = new JButton();
        toMenu.setIcon(new ImageIcon("Images/menu.png"));
        toMenu.setBorderPainted(false);
        toMenu.setBounds(400, 475, 70, 35);
        rules.add(toMenu, 2);
        rules.add(rulesBG, 1);
        wrapper.add(rules, "Rules");

        // constructs the game over screen
        final JLayeredPane gameOver = new JLayeredPane();
        gameOver.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        JLabel gameOverBG = new JLabel(new ImageIcon("Images/gameover_screen.png"));
        gameOverBG.setBounds(0, 0, WIDTH, HEIGHT);
        JButton toMenu2 = new JButton();
        toMenu2.setIcon(new ImageIcon("Images/menu.png"));
        toMenu2.setBorderPainted(false);
        toMenu2.setBounds(150, 355, 70, 35);
        JButton again = new JButton();
        again.setIcon(new ImageIcon("Images/play_again.png"));
        again.setBorderPainted(false);
        again.setBounds(300, 355, 126, 43);
        gameOver.add(toMenu2, new Integer(2));
        gameOver.add(again, new Integer(3));
        gameOver.add(gameOverBG, new Integer(1));
        wrapper.add(gameOver, "GameOver");

        // constructs the win screen
        final JLayeredPane win = new JLayeredPane();
        win.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        JLabel winBG = new JLabel(new ImageIcon("Images/win_screen.png"));
        winBG.setBounds(0, 0, WIDTH, HEIGHT);
        JButton toMenu3 = new JButton();
        toMenu3.setIcon(new ImageIcon("Images/menu.png"));
        toMenu3.setBorderPainted(false);
        toMenu3.setBounds(WIDTH/2 - 35,400, 70, 35);
        win.add(toMenu3, new Integer(2));
        win.add(winBG, new Integer(1));
        wrapper.add(win, "Win");

        // constructs the game
        final Game game = new Game();
        game.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        wrapper.add(game, "Game");

        // gets the CardLayout from the wrapper panel
        final CardLayout cl = (CardLayout) wrapper.getLayout();

        // the listener for the start button
        class startListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                frame.addKeyListener(game);
                cl.show(wrapper, "Game");
                game.start();
            }
        }

        class menuListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                cl.show(wrapper, "Menu");
                if(frame.getKeyListeners().length != 0)
                {
                    frame.removeKeyListener(game);
                }
            }
        }

        // the listener for the game
        class gameListener implements GameListener
        {
            public void gameEventReceived(GameEvent e)
            {
                // if the event was a game over event
                if((e.getName()).equalsIgnoreCase("Game Over"))
                {
                    // stops the game and shows the game over screen...
                    // which will just be the menu for now
                    game.stop();
                    cl.show(wrapper, "GameOver");
                    frame.removeKeyListener(game);
                    game.reset();
                }
                else if((e.getName()).equalsIgnoreCase("win"))
                {
                    game.stop();
                    cl.show(wrapper, "Win");
                    frame.removeKeyListener(game);
                    game.reset();
                }
                else if((e.getName()).equalsIgnoreCase("level complete"))
                {
                    game.stop();
                    frame.removeKeyListener(game);
                    cl.show(wrapper, "LvlComplete");
                }
            }
        }

        // adds the listeners
        start.addActionListener(new startListener());
        cont.addActionListener(new startListener());
        again.addActionListener(new startListener());
        game.addGameListener(new gameListener());
        toMenu.addActionListener(new menuListener());
        toMenu2.addActionListener(new menuListener());
        toMenu3.addActionListener(new menuListener());

        next.addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent e)
                {
                    cl.show(wrapper, "Rules");
                }
            }
        );
        toRules.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    cl.show(wrapper, "Story");
                }
            }
        );

        frame.add(wrapper);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setFocusable(true);
    }
}
