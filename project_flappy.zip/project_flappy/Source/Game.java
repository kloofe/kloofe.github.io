import java.awt.event.*;
import java.awt.geom.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.Timer;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import java.io.File;
import javax.sound.sampled.*;
import java.util.*;

/**
 * This class runs the overall game. Will start/stop levels, advance to the next level, draws all the objects, and
 * is also the keylistener. Does not contain the game logic; game logic is found in the level classes.
 * 
 */
public class Game extends JComponent implements ActionListener, KeyListener
{
    private Timer t;
    private ArrayList listeners;
    private Level[] lvls;
    private int currentLvl;
    private Clip clip;
    
    public Game()
    {
        // game timer
        t = new Timer(30, this);

        listeners = new ArrayList();

        lvls = new Level[3];
        lvls[0] = new Level1();
        lvls[1] = new Level2();
        lvls[2] = new Level3();
        // starts at level 1
        currentLvl = 0;
        playTune(); 
    }    

    public void gameLoop()
    {
        lvls[currentLvl].loop();
        // after the current level loops through once, checks whether the level is complete

        // if last level has been completed, the game event win is fired
        if(lvls[currentLvl].isComplete() && currentLvl == 2)
        {
            lvls[currentLvl].stop();
            fireEvent(this, "Win");
            clip.stop();
            playTune();
        }
        // if a level is complete, a level complete event is fired. The current level is also incremented
        else if(lvls[currentLvl].isComplete())
        {
            lvls[currentLvl].stop();
            currentLvl++;
            fireEvent(this, "Level Complete");
            clip.stop();
            playTune();
        }
        // if the player dies within a level, it's game over
        else if(lvls[currentLvl].isFailed())
        {
            lvls[currentLvl].stop();
            fireEvent(this, "Game Over");
            clip.stop();
            playTune();
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        // If the player has not started the level, the game will not loop
        if(lvls[currentLvl].isRunning())
        {
            gameLoop();
        }
        else
        {
            lvls[currentLvl].scroll();
        }
        // draws the screen
        // Even if the level is not started, there are still graphics on the screen (faby, the background, ground, etc)
        repaint();
    }

    public void paintComponent(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;

        g2.drawImage(lvls[currentLvl].getBG(), 0, 0, null);
        // gets all the objects from the current level and draws them
        ArrayList<GameObject> objects = lvls[currentLvl].getObjects();

        for(int i = 0; i < objects.size(); i++)
        {
            GameObject current = objects.get(i);
            // special instructions for pipes
            if(current instanceof Pipe)
            {
                // clipping used since the pipe image is large
                g2.setClip(current.getBoundaries());
                // draws the image with the set clipping
                g2.drawImage(current.getImg(), current.getX(), current.getY(), null);
                // no more clipping
                g2.setClip(null);
            }
            else if(current instanceof Faby)
            {
                if(!lvls[currentLvl].isRunning())
                {
                    g2.drawImage(current.getImg(), current.getX(), current.getY(), null);
                }
                else
                {
                    Faby faby = (Faby) current;
                    int l = faby.getImgs().size();
                    if (l > 0) {
                        g.drawImage(faby.getImgs().get(faby.getIndex() % l), faby.getX(), faby.getY(), (int) faby.getWidth(), (int) faby.getHeight(), this);
                    }
                }
            }
            else if(current instanceof Ground)
            {
                g2.drawImage(current.getImg(), current.getX(), current.getY(), null);
                g2.drawImage(current.getImg(), current.getX() + 550, current.getY(), null);
            }
            else
            {
                g2.drawImage(current.getImg(), current.getX(), current.getY(), null);
            }
        }
    }

    // starts the game
    public void start()
    {
        t.start();
    }

    // pauses/stops the game
    public void stop()
    {
        t.stop();
    }

    public int getLvl()
    {
        return currentLvl;
    }

    public void reset()
    {
        currentLvl = 0;
        for(int i = 0; i < lvls.length; i++)
        {
            lvls[i].reset();
        }
    }

    public void playTune()
    {
        File f;
        if(!lvls[currentLvl].isRunning()) f = new File("flappy.wav");
        else if(currentLvl==0) f = new File("candycrush.wav");
        else if(currentLvl==1) f = new File("Pacman.wav");
        else f = new File("mario.wav");

        try//enters a try-catch statement
        {
            AudioInputStream audio = AudioSystem.getAudioInputStream(f);//gets the audio from the file
            clip = AudioSystem.getClip();//obtains a clip that can be used for playing back an audio file or an audio stream.
            clip.open(audio);//opens the audio
            clip.start();//starts the clip
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
        catch (Exception e){System.out.println(e.getMessage());}
    }

    public void keyPressed(KeyEvent e)
    {
        int keyCode = e.getKeyCode();
        if(keyCode==KeyEvent.VK_SPACE)
        {
            // if the level has not been started, also starts the level
            if(!lvls[currentLvl].isRunning())
            {
                lvls[currentLvl].start();
                clip.stop();
                playTune();
            }
            lvls[currentLvl].moveFaby();
        }
    }

    public void keyReleased(KeyEvent e)
    {
        //do nothing
    }

    public void keyTyped(KeyEvent e)
    {
        // do nothing
    }

    // adds the custom event listener
    public synchronized void addGameListener(GameListener listener)  
    {
        listeners.add(listener);
    }

    // removes the custom event listener
    public synchronized void removeEventListener(ActionListener listener)   
    {
        listeners.remove(listener);
    }

    // fires a game event
    public synchronized void fireEvent(Object source, String n)
    {
        GameEvent event = new GameEvent(source, n);
        // goes through the game listeners
        Iterator gameListeners = listeners.iterator();
        while(gameListeners.hasNext())
        {
            ((GameListener) gameListeners.next()).gameEventReceived(event);
        }
    }
}
