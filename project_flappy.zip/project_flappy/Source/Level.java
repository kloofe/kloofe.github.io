import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.JComponent;
import javax.swing.Timer;
import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 * The basic level class. The classes that will extend this class will be level1, level2, etc.
 * Keeps track of all the objects. Contains most of the game logic. 
 * 
 */
public class Level
{
    protected Faby faby;
    protected ArrayList<GameObject> objects;
    protected long lastPipeTime;
    protected int totalPipes;
    protected int fabyDy;
    protected long powerupTime;
    protected boolean powerupActive;
    protected long powerupActiveTime;
    protected int powerupLength;
    protected long obstacleTime;
    protected boolean obstacleActive;
    protected long obstacleActiveTime;
    protected int obstacleLength;
    protected int gap;
    protected ImageIcon pipeImg;
    protected int speed;
    // for level 1, other levels based off of this
    protected final int DEFAULT_GAP = 300;
    protected final int POWERUP_GAP = 350;
    protected ImageIcon bg;
    protected Ground ground;
    private boolean running;
    private boolean alive;

    public Level()
    {
        faby = new Faby(100, 250);
        objects = new ArrayList<GameObject>();
        running = false;
        powerupActive = false;
        alive = true;
        fabyDy = -14;
        totalPipes = 0;
    }

    public void loop()
    {
        // faby can fly off the screen... but... well, he'll perpetually stay just out of sight. He hits an invisible wall :c
        // plus he'll still hit a pipe. So sucks for him.
        faby.incrementFrame();
        if(faby.getY() + faby.getHeight() + faby.getDy() > 0)
        {
            faby.move(faby.getDy());
        }
        else
        {
            faby.move(0);
        }

        scroll();
        // creates pipes every 3 seconds
        if(System.currentTimeMillis() >= lastPipeTime + 3000 && totalPipes != 10)
        {
            createPipes();
            lastPipeTime = System.currentTimeMillis();
        }

        Random generator = new Random();
        int r = generator.nextInt(100);
        // potentially creates powerup every 4 seconds
        // Powerups may only appear between the first and last pipe
        if(System.currentTimeMillis() >= powerupTime + 4000 && totalPipes > 0 && totalPipes < 10)
        {
            // 50% chance that a powerup will appear
            if(r < 50)
            {
                objects.add(getMyPowerup());
                powerupTime = System.currentTimeMillis();
            }
            // else powerup timer will start over
            else
            {
                powerupTime = System.currentTimeMillis();
            }
        }

        r = generator.nextInt(100);
        // potentially creates obstacles every 4.5 seconds
        // Obstacles may only appear between the first and last pipe
        if(System.currentTimeMillis() >= obstacleTime + 4500 && totalPipes > 0 && totalPipes < 10)
        {
            // 60% chance that an obstacle will appear
            if(r < 60)
            {
                objects.add(getMyObstacle());
                obstacleTime = System.currentTimeMillis();
            }
            // else powerup timer will start over
            else
            {
                obstacleTime = System.currentTimeMillis();
            }
        }

        for(int i = 0; i < objects.size(); i++)
        {
            GameObject current = objects.get(i);
            if(current.getBoundaries().intersects(faby.getBoundaries()))
            {
                // game over if faby runs into one of these obstacles
                if(current instanceof Pipe || current instanceof Shell || current instanceof Ground)
                {
                    alive = false;
                }
                else if(current instanceof Ghost)
                {
                    if(powerupActive)
                    {
                        objects.remove(i);
                        i--;
                    }
                    else
                    {
                        alive = false;
                    }
                }
                // chocolate = powerup that changes gap size
                else if(current instanceof Chocolate)
                {
                    if(!powerupActive)
                    {
                        // new gap size
                        gap = POWERUP_GAP;
                        // changes gap size of the pipes onscreen
                        for(int j = 0; j < objects.size(); j++)
                        {
                            if(objects.get(j) instanceof Pipe)
                            {
                                changeGapHeight((Pipe) objects.get(j), (Pipe) objects.get(j + 1), -(DEFAULT_GAP - POWERUP_GAP));

                                // skips next object since the next object will be the second pipe of the pair
                                j++;
                            }
                        }
                    }
                    powerupActive = true;
                    powerupActiveTime = System.currentTimeMillis();
                    objects.remove(current);
                    i--;
                }
                // mushroom powerup changes size of faby
                else if(current instanceof Mushroom)
                {
                    if(!powerupActive)
                    {
                        faby.shrink();
                    }
                    powerupActive = true;
                    powerupActiveTime = System.currentTimeMillis();
                    objects.remove(current);
                    i--;
                }
                // fruit powerup lets Faby eat ghosts
                else if(current instanceof Fruit)
                {
                    if(!powerupActive)
                    {
                        for(int j = 0; j < objects.size(); j++)
                        {
                            if(objects.get(j) instanceof Ghost)
                            {
                                Ghost ghost = (Ghost) objects.get(j);
                                ghost.setScared();
                            }
                        }
                    }
                    powerupActive = true;
                    powerupActiveTime = System.currentTimeMillis();
                    objects.remove(current);
                    i--;
                }
                // harder for faby to fly up
                else if(current instanceof Jelly)
                {                   
                    if(!obstacleActive)
                    {
                        fabyDy = -5;
                    }
                    obstacleActive = true;
                    obstacleActiveTime = System.currentTimeMillis();
                    objects.remove(current);
                    i--;
                }
            }
            // if Faby is off the screen and still runs into a pipe, he diessss. *EVIL CACKLE*
            else if((current.getX() <= faby.getX() && current.getX() >= faby.getX() + faby.getWidth()) && faby.getY() + faby.getHeight() < 0)
            {
                if(current instanceof Pipe)
                {
                    alive = false;
                }
            }
        }

        if(powerupActive && System.currentTimeMillis() >= powerupActiveTime + powerupLength)
        {
            revertFromPowerup();
            powerupActive = false;
        }

        if(obstacleActive && System.currentTimeMillis() >= obstacleActiveTime + obstacleLength)
        {
            revertFromObstacle();
            obstacleActive = false;
        }
    }

    protected void changeGapHeight(Pipe pipe1, Pipe pipe2, int gapChange)
    {
        pipe1.setHeight((int) pipe1.getHeight() - gapChange/2);
        pipe2.setHeight((int) pipe2.getHeight() - gapChange/2);
        pipe2.setYCoord(pipe2.getY() + gapChange/2);
    }

    // to be overridden
    protected GameObject getMyPowerup()
    {
        return new Jelly(0, 0);
    }

    // to be overridden
    protected GameObject getMyObstacle()
    {
        return new Jelly(0, 0);
    }

    // to be overridden in respective class
    // reverts game back to original state
    // disables powerup/obstacle
    protected void revertFromPowerup()
    {
    }

    // to be overridden in respective class
    protected void revertFromObstacle()
    {
    }

    private void createPipes()
    {
        int minimumHeight = 75;
        Random generator = new Random();
        int rand = generator.nextInt(570 - minimumHeight - gap) + minimumHeight;
        // adds pair of pipes
        objects.add(new Pipe(new Rectangle (550,0,50,rand), pipeImg));
        objects.add(new Pipe(new Rectangle(550,rand+gap-50,50, 590-rand-gap), pipeImg));
        totalPipes++;
    }

    public void moveFaby()
    {
        faby.setDy(fabyDy);
        faby.setIndex(0);
    }

    public boolean isFailed()
    {
        return !alive;
    }

    public boolean isComplete()
    {
        // level is complete once faby has flown for 5 seconds after last pipe
        return (totalPipes == 10) && (System.currentTimeMillis() > lastPipeTime + 5000);
    }

    public void scroll()
    {
        for(int i = 0; i < objects.size(); i++)
        {
            GameObject current = objects.get(i);
            current.move(speed);
            // if object is off the screen, removes the object
            if(current.getWidth() + current.getX() < 0)
            {
                if(current instanceof Ground)
                {
                    current.move(current.getWidth());
                }
                else
                {
                    objects.remove(i);
                    i--;
                }
            }
            if(current instanceof Shell)
            {
                Shell shell = (Shell) current;
                if(shell.getY() > 550)
                {
                    shell.setYCoord(0);
                }
                else 
                {
                    shell.setYCoord(shell.getY() + 10);
                }
            }
        }
    }

    public void start()
    {
        lastPipeTime = System.currentTimeMillis();
        running = true;
    }

    public void stop()
    {
        running = false;
    }

    public boolean isRunning()
    {
        return running;
    }

    public Image getBG()
    {
        return bg.getImage();
    }

    public void reset()
    {
        running = false;
        powerupActive = false;
        alive = true;
        totalPipes = 0;
        objects.removeAll(objects);
        objects.add(ground);
        faby.setYCoord(250);
        powerupTime = System.currentTimeMillis();
        obstacleTime = System.currentTimeMillis();
    }

    public ArrayList<GameObject> getObjects()
    {
        // adds Faby into a copy array list and then returns that array list
        ArrayList<GameObject> complete = new ArrayList<GameObject>();
        complete.add(faby);
        complete.addAll(objects);
        return complete;
    }
}
