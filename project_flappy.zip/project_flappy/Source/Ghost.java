import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * Write a description of class Ghost here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ghost implements GameObject
{
    private Image img;
    private Rectangle boundaries;
    private final ImageIcon IMAGE = new ImageIcon("Images/ghost.png");
    private final ImageIcon IMAGE_S = new ImageIcon("Images/ghost_p.png");

    /**
     * Constructor for objects of class Ghost
     */
    public Ghost(int xCoord, int yCoord)
    {
        boundaries = new Rectangle(xCoord, yCoord, IMAGE.getIconWidth(), IMAGE.getIconHeight());
        img = IMAGE.getImage();
        // boundaries will also be initialized but we can do that once we know how big
        // it will be
    }

    public int getX()
    {
        return (int) boundaries.getX();
    }

    public int getY()
    {
        return (int) boundaries.getY();
    }

    public int getWidth()
    {
        return (int) boundaries.getWidth();
    }

    public int getHeight()
    {
        return (int) boundaries.getHeight();
    }

    public void setXCoord(int x)
    {
        boundaries.setRect(x, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }

    public Rectangle getBoundaries()
    {
        return boundaries;
    }

    public Image getImg()
    {
        return img;
    }

    public void setScared()
    {
        img = IMAGE_S.getImage();
    }

    public void setNormal()
    {
        img = IMAGE.getImage();
    }

    public void move(int dx)
    {
        boundaries.setRect(boundaries.getX()+dx, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }
}
