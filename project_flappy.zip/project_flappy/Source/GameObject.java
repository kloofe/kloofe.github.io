import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Write a description of interface GameObject here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface GameObject
{
    // these are the methods that all of the game objects need
    int getX();
    int getY();
    Rectangle getBoundaries();
    Image getImg();
    void move(int distance);
    int getWidth();
    int getHeight();
}
