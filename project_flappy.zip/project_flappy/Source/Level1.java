import javax.swing.ImageIcon;
import java.util.Random;
/**
 * Power-up unique to the level is chocolate
 * Chocolate makes the gap wider
 * 
 * Obstacle unique to the level is jelly
 * Jelly makes you drop faster
 */
public class Level1 extends Level
{
    public Level1()
    {
        super();

        speed = -5;
        gap = DEFAULT_GAP;
        pipeImg = Pipe.LEVEL1;
        powerupLength = 4000;
        obstacleLength = 4000;
        ground = new Ground(0, 540, Ground.GR1);
        objects.add(ground);
        bg = new ImageIcon("Images/candycrush_bg.png");
    }

    public void revertFromPowerup()
    {
        gap = DEFAULT_GAP;
        for(int j = 0; j < objects.size(); j ++)
        {
            if(objects.get(j) instanceof Pipe)
            {
                changeGapHeight((Pipe) objects.get(j), (Pipe) objects.get(j + 1), DEFAULT_GAP - POWERUP_GAP);
                j++;
            }
        }
    }

    // reset Faby's dy
    public void revertFromObstacle()
    {
        fabyDy = -14;
    }

    /**
     * @overide
     */
    public GameObject getMyPowerup()
    {
        Random generator = new Random();
        int randY = generator.nextInt(470);
        Chocolate powerup = new Chocolate(550, randY);
        for(int i = 0; i < objects.size(); i++)
        {
            if(powerup.getBoundaries().intersects(objects.get(i).getBoundaries()))
            {
                powerup.setXCoord(powerup.getX() + powerup.getWidth() + objects.get(i).getWidth());
            }
        }

        return powerup;
    }

    /**
     * @overide
     */
    public GameObject getMyObstacle()
    {
        Random generator = new Random();
        int randY = generator.nextInt(470);
        Jelly obstacle = new Jelly(550, randY);
        for(int i = 0; i < objects.size(); i++)
        {
            if(obstacle.getBoundaries().intersects(objects.get(i).getBoundaries()))
            {
                obstacle.setXCoord(obstacle.getX() + obstacle.getWidth() + objects.get(i).getWidth());
            }
        }
        return obstacle;
    }
}