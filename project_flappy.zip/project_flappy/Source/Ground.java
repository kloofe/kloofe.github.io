import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * Write a description of class Ground here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ground implements GameObject
{
    private Image img;
    private int gap;
    private Rectangle boundaries;
    public final static ImageIcon GR1 = new ImageIcon("Images/bricks_ground.png");
    public final static ImageIcon GR2 = new ImageIcon("Images/pacman_ground.png");
    public final static ImageIcon GR3 = new ImageIcon("Images/mario_ground.png");
    public Ground(int xCoord, int yCoord, ImageIcon i)
    {
        img = i.getImage();
        boundaries = new Rectangle(xCoord, yCoord, img.getWidth(null), img.getHeight(null));
    }

    public int getX()
    {
        return (int) boundaries.getX();
    }

    public int getY()
    {
        return (int) boundaries.getY();
    }

    public Rectangle getBoundaries()
    {
        return boundaries;
    }

    public Image getImg()
    {
        return img;
    }

    public int getWidth()
    {
        return (int) boundaries.getWidth();
    }

    public int getHeight()
    {
        return (int) boundaries.getHeight();
    }

    public void move(int dx)
    {
        boundaries.setRect(boundaries.getX()+dx, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }
}
