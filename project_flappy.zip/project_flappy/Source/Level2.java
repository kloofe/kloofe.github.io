import javax.swing.ImageIcon;
import java.util.Random;
/**
 * Power-up unique to the level is fruit
 * Fruit lets player eat ghosts
 * 
 * Obstacle unique to the level is ghosts
 * Running into the ghost will kill you
 */
public class Level2 extends Level
{
    /**
     * Constructor for objects of class Level2
     */
    public Level2()
    {
        super();

        speed = -5;
        gap = DEFAULT_GAP - 50;
        pipeImg = Pipe.LEVEL2;
        powerupLength = 3000;
        ground = new Ground(0, 540, Ground.GR2);
        objects.add(ground);
        bg = new ImageIcon("Images/pacman_bg.png");
    }

    public void revertFromPowerup()
    {
        for(int i = 0; i < objects.size(); i++)
        {
            GameObject current = objects.get(i);
            if(current instanceof Ghost)
            {
                Ghost ghost = (Ghost) current;
                ghost.setNormal();
            }
        }
    }

    /**
     * @overide
     */
    public GameObject getMyPowerup()
    {
        Random generator = new Random();
        int randY = generator.nextInt(470);
        Fruit powerup = new Fruit(550, randY);
        for(int i = 0; i < objects.size(); i++)
        {
            if(powerup.getBoundaries().intersects(objects.get(i).getBoundaries()))
            {
                powerup.setXCoord(powerup.getX() + powerup.getWidth() + objects.get(i).getWidth());
            }
        }

        return powerup;
    }

    /**
     * @overide
     */
    public GameObject getMyObstacle()
    {
        Random generator = new Random();
        int randY = generator.nextInt(470);
        Ghost obstacle = new Ghost(550, randY);
        if(powerupActive)
        {
            obstacle.setScared();
        }
        for(int i = 0; i < objects.size(); i++)
        {
            if(obstacle.getBoundaries().intersects(objects.get(i).getBoundaries()))
            {
                obstacle.setXCoord(obstacle.getX() + obstacle.getWidth() + objects.get(i).getWidth());
            }
        }
        return obstacle;
    }
}