import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.io.IOException;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.File;
import java.util.Iterator;
/**
 * Write a description of class Faby here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Faby implements GameObject
{
    private Image img;
    private Rectangle boundaries;
    private int dy;
    private ArrayList<BufferedImage> imgs;
    private final ImageIcon IMAGE_STATIC = new ImageIcon("Images/faby_stationary.gif");
    private ImageIcon imgage = new ImageIcon("Images/faby_tilted.gif");
    private int currIndex = 0;

    /**
     * Constructor for objects of class Faby
     */
    public Faby(int xCoord, int yCoord)
    {
        dy = 0;
        boundaries = new Rectangle(xCoord, yCoord, imgage.getIconWidth(), imgage.getIconHeight());
        imgs = new ArrayList<BufferedImage>();
        BufferedImage bi=null;
        ImageInputStream iis = null;
        try
        {
            iis = ImageIO.createImageInputStream(new File("Images/faby_tilted.gif"));
        }
        catch(IOException e)
        {
        }
        Iterator<ImageReader> iter = ImageIO.getImageReaders(iis);
        for ( ; iter.hasNext(); ) {
            ImageReader r = iter.next();
            r.setInput(iis);
            int n = 0;
            try
            {
                n = r.getNumImages(true);
            }
            catch(IOException e)
            {
            }
            for (int i = 0; i < n; i++) {
                try
                {
                    bi = r.read(i);
                }
                catch(IOException e)
                {
                }

                imgs.add(bi);
            }
        }
        try
        {
            iis.close();
        }
        catch(IOException e)
        {
        }
        img = IMAGE_STATIC.getImage();
    }

    public void incrementFrame() {
        int l = imgs.size();
        if (currIndex + 1 < l) {
            currIndex += 1;
        }
    }

    public void setIndex(int i)
    {
        currIndex = 1;
    }

    public void setDy(int d)
    {
        dy = d;
    }

    public int getX()
    {
        return (int) boundaries.getX();
    }

    public int getY()
    {
        return (int) boundaries.getY();
    }

    public void setYCoord(int y)
    {
        boundaries.setRect(boundaries.getX(), y, boundaries.getWidth(), boundaries.getHeight());
    }

    public int getWidth()
    {
        return (int) boundaries.getWidth();
    }

    public int getHeight()
    {
        return (int) boundaries.getHeight();
    }

    public Rectangle getBoundaries()
    {
        return boundaries;
    }

    public Image getImg()
    {
        return img;
    }

    public ArrayList<BufferedImage> getImgs()
    {
        return imgs;
    }

    public int getIndex()
    {
        return currIndex;
    }

    public void setImg(Image i)
    {
        img = i;
    }

    public void move(int d)
    {
        //jumping
        boundaries.setRect(boundaries.getX(), boundaries.getY()+d, boundaries.getWidth(), boundaries.getHeight());
        dy++;
    }

    public void shrink()
    {
        boundaries.setRect(boundaries.getX(), boundaries.getY(), boundaries.getWidth()/2, boundaries.getHeight()/2);
    }

    public void enlarge()
    {
        boundaries.setRect(boundaries.getX(), boundaries.getY(), boundaries.getWidth()*2, boundaries.getHeight()*2);        
    }

    public int getDy()
    {
        return dy;
    }

}
