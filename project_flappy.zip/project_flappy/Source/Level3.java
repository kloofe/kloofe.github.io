import javax.swing.ImageIcon;
import java.util.Random;
/**
 * Power-up unique to the level is mushroom
 * Mushroom makes you smaller
 * 
 * Obstacle unique to the level is Shell
 * Shell makes you die :c
 * 
 */
public class Level3 extends Level
{

    /**
     * Constructor for objects of class Level3
     */
    public Level3()
    {
        super();

        speed = -5;
        gap = DEFAULT_GAP - 75;
        pipeImg = Pipe.LEVEL3;
        powerupLength = 4000;
        ground = new Ground(0, 540, Ground.GR3);
        objects.add(ground);
        bg = new ImageIcon("Images/mario_bg.png");
    }

    public void revertFromPowerup()
    {
        faby.enlarge();
    }

    public GameObject getMyPowerup()
    {
        Random generator = new Random();
        int randY = generator.nextInt(470);
        Mushroom powerup = new Mushroom(550, randY);
        for(int i = 0; i < objects.size(); i++)
        {
            if(powerup.getBoundaries().intersects(objects.get(i).getBoundaries()))
            {
                powerup.setXCoord(powerup.getX() + powerup.getWidth() + objects.get(i).getWidth());
            }
        }

        return powerup;
    }

    public GameObject getMyObstacle()
    {
        Random generator = new Random();
        int randY = generator.nextInt(470);
        Shell obstacle = new Shell(550, randY);
        for(int i = 0; i < objects.size(); i++)
        {
            if(obstacle.getBoundaries().intersects(objects.get(i).getBoundaries()))
            {
                obstacle.setXCoord(obstacle.getX() + obstacle.getWidth() + objects.get(i).getWidth());
            }
        }
        return obstacle;
    }
}
