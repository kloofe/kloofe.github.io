import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * Write a description of class Pipes here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pipe implements GameObject
{
    private Image img;
    private int gap;
    private Rectangle boundaries;
    public final static ImageIcon LEVEL1 = new ImageIcon("Images/candy_pipe.png");
    public final static ImageIcon LEVEL2 = new ImageIcon("Images/pacman_pipe.png");
    public final static ImageIcon LEVEL3 = new ImageIcon("Images/mario_pipe.png");

    /**
     * Constructor for objects of class Pipes
     */
    public Pipe(Rectangle p, ImageIcon i)
    {
        img = i.getImage();
        boundaries = p;
    }

    public int getX()
    {
        return (int) boundaries.getX();
    }

    public int getY()
    {
        return (int) boundaries.getY();
    }

    public int getWidth()
    {
        return (int) boundaries.getWidth();
    }

    public int getHeight()
    {
        return (int) boundaries.getHeight();
    }

    public void setHeight(int h)
    {
        boundaries.setRect(boundaries.getX(), boundaries.getY(), boundaries.getWidth(), h);
    }

    public void setYCoord(int y)
    {
        boundaries.setRect(boundaries.getX(), y, boundaries.getWidth(), boundaries.getHeight());
    }

    public void setXCoord(int x)
    {
        boundaries.setRect(x, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }

    public Rectangle getBoundaries()
    {
        return boundaries;
    }

    public Image getImg()
    {
        return img;
    }

    public void move(int dx)
    {
        boundaries.setRect(boundaries.getX()+dx, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }
}
