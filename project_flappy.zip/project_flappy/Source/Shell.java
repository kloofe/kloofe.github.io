import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * Write a description of class Shell here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shell implements GameObject
{
    private Image img;
    private Rectangle boundaries;
    private final ImageIcon IMAGE = new ImageIcon("Images/shell.png");
    private int dy;

    /**
     * Constructor for objects of class Shell
     */
    public Shell(int xCoord, int yCoord)
    {
        boundaries = new Rectangle(xCoord, yCoord, IMAGE.getIconWidth(), IMAGE.getIconHeight());
        img = IMAGE.getImage();
        dy = 5;
    }

    public int getX()
    {
        return (int) boundaries.getX();
    }

    public int getY()
    {
        return (int) boundaries.getY();
    }

    public int getWidth()
    {
        return (int) boundaries.getWidth();
    }

    public int getHeight()
    {
        return (int) boundaries.getHeight();
    }

    public void setXCoord(int x)
    {
        boundaries.setRect(x, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }

    public void setYCoord(int y)
    {
        boundaries.setRect(boundaries.getX(), y, boundaries.getWidth(), boundaries.getHeight());
    }

    public Rectangle getBoundaries()
    {
        return boundaries;
    }

    public Image getImg()
    {
        return img;
    }

    public void move(int dx)
    {
        boundaries.setRect(boundaries.getX()+dx, boundaries.getY(), boundaries.getWidth(), boundaries.getHeight());
    }
}
