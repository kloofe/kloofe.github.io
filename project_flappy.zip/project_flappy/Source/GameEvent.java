import java.util.EventObject;

// custom event
public class GameEvent extends EventObject
{
    private String name;
    
    public GameEvent(Object source, String n)
    {
        super(source);
        name = n;
    }

    public String getName()
    {
        return name;
    }
}
